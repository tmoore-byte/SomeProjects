# CPSC350_A2

Assignment 2 - Game Of Life
Andy Anguiano - 2316199
Thomas Moore - 2318524

Resources:
TLT Center Tutors;
TA - Micheal;
Class Textbook

We worked on the assignment together only one pushed changes
